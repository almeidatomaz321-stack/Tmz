# Battle Royale 2D — contas online (sem Firebase)

Contas, IDs de jogador e perfil ranqueado são compartilhados entre celulares por um backend Node.js + SQLite.

## Como iniciar localmente
1. Instale Node.js 20 ou mais recente.
2. No diretório do projeto, execute `npm install`.
3. Copie `.env.example` para `.env` (opcional; ajuste as variáveis).
4. Execute `npm start`.
5. Abra `http://localhost:3000`.

## Para funcionar em celulares diferentes
O servidor precisa estar publicado na internet com HTTPS e armazenamento persistente. Faça deploy do projeto em um serviço que suporte Node.js e disco persistente; configure o disco para manter `accounts.sqlite`. Não use filesystem temporário, pois os dados podem ser apagados ao reiniciar/redeploy. Configure domínio HTTPS. Os celulares devem abrir o mesmo endereço público do jogo.


## Recursos incluídos
- Criar conta e login usando nome de usuário e senha.
- ID único BR-XXXXXXXX criado no servidor.
- Senha armazenada com scrypt e salt (não em texto puro).
- Sessões bearer com tokens aleatórios, validade de 30 dias e logout.
- Banco SQLite com contas e perfil ranqueado.
- Sincronização do perfil ranqueado (pontos, moedas, recompensas e skins) entre dispositivos ao autenticar.
- Limite de tentativas de login/cadastro por IP.
- Sem Firebase, OAuth Google ou serviços de banco terceirizados.

## Limitações e cuidados
- O SQLite fica no servidor. Faça backups regulares do arquivo de banco.
- Use HTTPS em produção; não publique em HTTP.
- Este é um backend inicial para jogo/protótipo, não anti-cheat. Não confie em valores de perfil enviados pelo cliente para rankings competitivos sem validação server-side.
- O login guarda o token no navegador do dispositivo. Evite aparelhos compartilhados e faça logout.
- Se hospedar API e frontend em domínios diferentes, preencha `ALLOWED_ORIGINS` com a origem exata do jogo.
