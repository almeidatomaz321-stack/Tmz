'use strict';
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const { promisify } = require('util');
const scrypt = promisify(crypto.scrypt);
const app = express();
const db = new Database(process.env.DB_FILE || './accounts.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS accounts (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, created_at INTEGER NOT NULL, profile_json TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);`);
const port = Number(process.env.PORT || 3000);
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'32kb'}));
app.use((req,res,next)=>{
 const origin=req.headers.origin;
 if (!origin || allowedOrigins.length===0 || allowedOrigins.includes(origin)) {
  if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Credentials','false');}
  res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods','GET, POST, PUT, DELETE, OPTIONS');
 }
 if(req.method==='OPTIONS')return res.sendStatus(204);next();
});
app.use('/api/auth', rateLimit({windowMs:15*60*1000,max:40,standardHeaders:true,legacyHeaders:false}));
const cleanUsername=s=>typeof s==='string'?s.trim().replace(/\s+/g,' ').slice(0,22):'';
const tokenHash=t=>crypto.createHash('sha256').update(t).digest('hex');
async function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){
 const buf=await scrypt(password,salt,64);return `${salt}:${buf.toString('hex')}`;
}
async function verifyPassword(password,stored){
 try{const [salt,hex]=stored.split(':');const expected=Buffer.from(hex,'hex'),actual=await scrypt(password,salt,64);return expected.length===actual.length&&crypto.timingSafeEqual(expected,actual)}catch{return false}
}
function makePlayerId(){return 'BR-'+crypto.randomBytes(4).toString('hex').toUpperCase()}
function newSession(accountId){const token=crypto.randomBytes(32).toString('base64url');db.prepare('INSERT INTO sessions(token_hash,account_id,expires_at) VALUES(?,?,?)').run(tokenHash(token),accountId,Date.now()+30*24*60*60*1000);return token}
function auth(req,res,next){const header=req.headers.authorization||'',token=header.startsWith('Bearer ')?header.slice(7):'';if(!token)return res.status(401).json({error:'Faça login novamente.'});const row=db.prepare('SELECT a.id,a.username,s.expires_at FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=?').get(tokenHash(token));if(!row||row.expires_at<Date.now()){if(row)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(token));return res.status(401).json({error:'Sessão expirada.'})}req.account=row;req.tokenHash=tokenHash(token);next();}
app.post('/api/auth/register',async(req,res)=>{
 const username=cleanUsername(req.body?.username),password=req.body?.password;
 if(username.length<3||username.length>22)return res.status(400).json({error:'Nome precisa ter de 3 a 22 caracteres.'});
 if(typeof password!=='string'||password.length<8||password.length>100)return res.status(400).json({error:'Senha precisa ter 8 a 100 caracteres.'});
 const id=makePlayerId(),pass=await hashPassword(password);
 try{db.prepare('INSERT INTO accounts(id,username,password_hash,created_at) VALUES(?,?,?,?)').run(id,username,pass,Date.now());const token=newSession(id);res.json({token,account:{id,username}})}catch(e){if(String(e).includes('UNIQUE'))return res.status(409).json({error:'Nome já está em uso. Escolha outro.'});console.error(e);res.status(500).json({error:'Erro ao criar conta.'})}
});
app.post('/api/auth/login',async(req,res)=>{
 const username=cleanUsername(req.body?.username),password=req.body?.password;
 const acc=db.prepare('SELECT id,username,password_hash,profile_json FROM accounts WHERE username=?').get(username);
 if(!acc||typeof password!=='string'||!await verifyPassword(password,acc.password_hash))return res.status(401).json({error:'Nome ou senha incorretos.'});
 const token=newSession(acc.id);res.json({token,account:{id:acc.id,username:acc.username},profile:acc.profile_json?JSON.parse(acc.profile_json):null});
});
app.get('/api/auth/me',auth,(req,res)=>res.json({account:{id:req.account.id,username:req.account.username}}));
app.put('/api/profile',auth,(req,res)=>{
 const profile=req.body?.profile;if(!profile||typeof profile!=='object'||Array.isArray(profile))return res.status(400).json({error:'Perfil inválido.'});
 const json=JSON.stringify(profile);if(json.length>16000)return res.status(413).json({error:'Perfil muito grande.'});
 db.prepare('UPDATE accounts SET profile_json=? WHERE id=?').run(json,req.account.id);res.json({ok:true});
});
app.get('/api/profile',auth,(req,res)=>{const row=db.prepare('SELECT profile_json FROM accounts WHERE id=?').get(req.account.id);res.json({profile:row?.profile_json?JSON.parse(row.profile_json):null});});
app.post('/api/auth/logout',auth,(req,res)=>{db.prepare('DELETE FROM sessions WHERE token_hash=?').run(req.tokenHash);res.json({ok:true});});
app.get('/api/health',(_req,res)=>res.json({ok:true}));
app.use(express.static('public'));
db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
app.listen(port,'0.0.0.0',()=>console.log(`Battle Royale account server listening on ${port}`));
